# count the number of classes in the coco dataset train/train_sets.json
import json

with open('/Users/mac/Desktop/Research/InProgress/SPINLegoRecog/DeepBrick/dataset-phase2/trainable/train/train_set.json', 'r') as f:
    data = json.load(f)
    print(len(data['categories']))
    for category in data['categories']:
        print(category['name'])

