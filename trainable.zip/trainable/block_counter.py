# count the number of blocks in the testing dataset
import os
import cv2

# remove all the files in './canny/'
for file in os.listdir('./canny/'):
    os.remove('./canny/' + file)

# we use the Sobel edge detector to detect the edges of the image in the testing dataset './test/'
# we use the './test/' as the input directory
for file in os.listdir('./test/'):
    if file.endswith('.jpg'):
        print(file)
        img = cv2.imread('./test/' + file)
        # draw the edges of the image in the testing dataset './test/'
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # Blur the image for better edge detection
        img_blur = cv2.GaussianBlur(img_gray, (3,3), 0)
        # Sobel Edge Detection
        # sobelx = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=0, ksize=5) # Sobel Edge Detection on the X axis
        sobely = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=0, dy=1, ksize=5) # Sobel Edge Detection on the Y axis
        # sobelxy = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=1, ksize=5) # Combined X and Y Sobel Edge Detection
        # Display Sobel Edge Detection Images
        # save the Sobel Edge Detection Images in './canny/'
        cv2.imwrite('./canny/' + file, sobely)
