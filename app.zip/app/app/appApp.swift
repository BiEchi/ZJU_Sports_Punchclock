//
//  appApp.swift
//  app
//
//  Created by Jack's Macbook Pro on 2021/12/14.
//

import SwiftUI

@main
struct appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
